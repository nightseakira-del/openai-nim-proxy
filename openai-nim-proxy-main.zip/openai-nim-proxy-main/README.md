# openai-nim-proxy
OpenAI compatible proxy for NVIDIA NIM API
